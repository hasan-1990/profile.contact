import gif from "../gif/Spinner.gif"

import React from 'react'

const Spiner = () => {
  return (
    <div>
    <img src={gif} alt="11" />
      
    </div>
  )
}

export default Spiner
