import axios from "axios";
const SERVER_URL ="http://localhost:9000";

export const getAllContacts =()=>{
    const url  = `${SERVER_URL}/Contacts`
    return axios.get(url)
}

export const getContact =(Contactid)=>{
    const url  = `${SERVER_URL}/Contacts/${Contactid}`
    return axios.get(url)
}
export const getAllGroups =()=>{
    const url  = `${SERVER_URL}/groups`
    return axios.get(url)
}
export const getContactById =(contactid)=>{
    const url  = `${SERVER_URL}/Contacts/${contactid}`
    return axios.get(url)
}
export const getGroup =(groupsid)=>{
    const url  = `${SERVER_URL}/groups/${groupsid}`
    return axios.get(url)
}
export const createContact =(contact)=>{
    const url  = `${SERVER_URL}/Contacts/`
    return axios.post(url,contact)
}
export const Updatecontact =(contact,contactid)=>{
    const url  = `${SERVER_URL}/Contacts/${contactid}`
    return axios.put(url,contact)
}
export const deletecontact =(contactid)=>{
    const url  = `${SERVER_URL}/contacts/${contactid}`
    return axios.delete(url)
}
