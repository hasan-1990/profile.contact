import React from "react";
import "./css/font.css";
import {
  getAllContacts,
  getAllGroups,
  createContact,
} from "./component/serverurl.js";
import { useEffect } from "react";
import { useState } from "react";
import {
  Contact,
  Contacts,
  // Search,
  Navbar,
  Addcontact,
  Editcontact,
  Viewcontact,
  // Deletcontact,
} from "./component/Index.jsx";
import { Routes, Route, Navigate, useNavigate } from "react-router-dom";

const App = () => {
  const [getcontacts, setContacts] = useState([]);
  const [forceRender, setForceRender] = useState(false);
  const [loading, setLoading] = useState(false);
  const [getGroups, setGroups] = useState([]);
  const [getContact, setContact] = useState({
    fullname: "",
    email: "",
    mobilenumber: "",
    address: "",
    group: "",
    job: "",
    photo: "",
  });

  const navigate = useNavigate();
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const { data: contactsData } = await getAllContacts();
        const { data: groupsData } = await getAllGroups();
        setContacts(contactsData);
        setGroups(groupsData);
        setLoading(false);
        console.log(contactsData);
        console.log(groupsData);
      } catch (error) {
        console.log(error.massege);
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const setContactinfo = (event) => {
    setContact({ ...getContact, [event.target.name]: event.target.value });
  };
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const { data: contactsData } = await getAllContacts();
        setContacts(contactsData);
        setLoading(false);
      } catch (error) {
        console.log(error.massege);
        setLoading(false);
      }
    };
    fetchData();
  }, [forceRender]);
  const createContactForm = async (event) => {
    event.preventDefault();
    try {
      const { status } = await createContact(getContact);
      if (status === 201) {
        setForceRender(!forceRender);
        setContact({});
        alert("contact created successfully");
        navigate("/contacts");
      }
    } catch (error) {
      console.log(error.massege);
    }
  };
  return (
    <>
    
      <Navbar />
      <Routes>
        <Route path="/" element={<Navigate to="/contacts" />} />
        <Route
          path="/contacts"
          element={<Contacts contacts={getcontacts} loading={loading} />}
        />
        <Route path="/contacts/:contactid" element={<Viewcontact />} />
        <Route
          path="/contacts/add"
          element={
            <Addcontact
              setContactinfo={setContactinfo}
              groups={getGroups}
              createContactForm={createContactForm}
            />
          }
        />
        <Route path="/contacts/edit:contactID" element={<Editcontact />} />
        <Route path="/contacts/edit:contactID" element={<Viewcontact />} />
      </Routes>
    </>
  );
};

export default App;
